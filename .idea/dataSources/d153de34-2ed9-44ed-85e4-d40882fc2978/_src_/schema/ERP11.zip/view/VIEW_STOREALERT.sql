CREATE VIEW VIEW_STOREALERT AS select a.uuid,a.name,a.storenum,nvl(b.outnum,0) as outnum from (
    select g.uuid,g.name,sum(nvl(sd.num,0)) as storenum from goods g, storedetail sd
    where g.uuid=sd.goodsuuid(+) 
    group by g.uuid,g.name
) a, (
    select od.goodsuuid,sum(od.num) as outnum from orderdetail od, orders o
    where o.uuid=od.ordersuuid
    and o.type='2' and od.state='0'
    group by od.goodsuuid
) b
where a.uuid=b.goodsuuid
/
